
public class stringcase {
	public int add(int a, int b){
		return a+b;
		
		
	}
	public String Concat (String a, String b) {
		return a+b;
		
	}
}
