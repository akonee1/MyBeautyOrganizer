import static org.junit.Assert.*;

import org.junit.Test;


public class stringcaseTest {

	@Test
	public void Addfunctiontest() {
		Junitz junit = new Junitz();
		int result = junit.add(1, 2);
		assertEquals(1, result);
			
	}

}
