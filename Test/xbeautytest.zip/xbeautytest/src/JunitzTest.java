
import static org.junit.Assert.*;

import org.junit.Test;

public class JunitzTest {

	@Test
	public void Addfunctiontest() {
		Junitz junit = new Junitz();
		int result = junit.add(2, 1);
		assertEquals(3, result);
			
	}

}
